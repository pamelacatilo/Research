Inro to Python 

Python is a scripting language like many other languages. 

There are two modes of running Pyhton:

*A command prompt REPL (Read, Eval, Print and loop)
*Programs can be developed in a Text Editor (IDE) and run

Multiple paradigms:

*Functional
*Obeject Oriented
*Procedural

Getting Python

Best Method is install the Anaconda Distribution of Python

*https://www.anaconda.com/download/

Why SQL?

*Jump start your Data Query and Wrangling Capability
*SQL just makes sense
*Scalability and Performance


1. The easiest way to use SQL  - pysqldf 

pandasql allows you to query pandas DataFrames using SQL syntax. It works similarly to sqldf in R. 
pandasql seeks to provide a more familiar way of manipulating and cleaning data for people new to Python or pandas.

*Uses SQLLite under the covers and SQL  is somewhat limited
*Can treat Pandas data frames as if they were tables
*Good for all small workloads

To install pysqldf

>pip install - U
pandasql
>pip install - U
pysqldf

2. Using SQLite

*Automatically Installed with Python. Batteries included.

*Built-in Fully functional database

*Good SQL support

*Greate for local application or analysis work.

3. Accessing SQL Server from Python with ODBC 

*Accessing SQL databases - using ODBC to connect to databases

*Maximum Flexibility

*A production grade solution





