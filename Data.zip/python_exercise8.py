#Multiplication table
n = int(input("Input a number: "))

# use for loop to iterate 10 times
for i in range(1,13):
   print(n,'x',i,'=',n*i)